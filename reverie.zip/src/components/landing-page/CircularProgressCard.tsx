import { CircularProgressWidget } from '../ui/circular-progress';

export default function CircularProgressCard() {
  return (
    <>
      <CircularProgressWidget />
    </>
  );
}
