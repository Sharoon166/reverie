// This file is deprecated. KPIs are now shown on the landing page.
