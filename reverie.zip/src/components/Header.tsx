'use client';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { useRef, useState, useLayoutEffect } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  Menu,
  X,
  Home,
  Users,
  FileText,
  User,
  Coins,
  BarChart2,
  Target,
  Code2,
} from 'lucide-react';
import { Button } from './ui/button';

export default function Header() {
  const navItems = [
    {
      name: 'Dashboard',
      href: '/',
      icon: Home,
    },
    {
      name: 'Leads',
      href: '/leads',
      icon: Users,
    },
    {
      name: 'Clients',
      href: '/clients',
      icon: User,
    },
    {
      name: 'Invoices',
      href: '/invoices',
      icon: FileText,
    },
    {
      name: 'Employees',
      href: '/employees',
      icon: Users,
    },
    {
      name: 'Expenses',
      href: '/expenses',
      icon: Coins,
    },
    {
      name: 'Reports',
      href: '/reports',
      icon: BarChart2,
    },
    {
      name: 'Goals',
      href: '/goals',
      icon: Target,
    },
  ];

  const pathname = usePathname();
  // Find the nav item whose href is a prefix of the current pathname
  const activeItem =
    navItems.find((item) =>
      item.href === '/' ? pathname === '/' : pathname.startsWith(item.href)
    )?.name || 'Dashboard';
  const [target, setTarget] = useState(activeItem);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navRef = useRef<HTMLDivElement>(null);
  const mobileMenuRef = useRef<HTMLDivElement>(null); // capsule animates here
  const [capsule, setCapsule] = useState<{
    left: number;
    width: number;
  } | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);

  // Close mobile menu when clicking outside
  useLayoutEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        mobileMenuRef.current &&
        !mobileMenuRef.current.contains(event.target as Node)
      ) {
        setMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Update capsule position whenever target changes
  useLayoutEffect(() => {
    if (!navRef.current) return;
    const el = navRef.current.querySelector<HTMLDivElement>(
      `[data-item="${target}"]`
    );
    if (el) {
      setCapsule({ left: el.offsetLeft, width: el.offsetWidth });
    }
  }, [target]);

  // Update capsule when route changes
  useLayoutEffect(() => {
    setTarget(activeItem);
  }, [activeItem]);

  return (
    <header className="relative">
      <div className="flex justify-between items-center">
        {/* Logo */}
        <Link
          href="/"
          className="text-lg px-4 py-1 border border-black rounded-full"
        >
          Reverie
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-2">
          <nav
            ref={navRef}
            className="relative flex items-center gap-2 bg-white rounded-full shadow-sm"
            onMouseLeave={() => {
              setTarget(activeItem);
              setHovered(null);
            }}
          >
            {capsule && (
              <motion.div
                className="absolute top-0 bottom-0 z-0 rounded-full bg-black/90"
                style={{ left: 0 }}
                animate={{ left: capsule.left, width: capsule.width }}
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            )}

            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                data-item={item.name}
                className="relative px-4 py-3 text-sm font-medium cursor-pointer z-10"
                onMouseEnter={() => {
                  setHovered(item.name);
                }}
                onClick={() => {
                  setTarget(item.name);
                }}
              >
                <span
                  className={cn('relative z-10', {
                    'text-white':
                      hovered === item.name ||
                      (!hovered && activeItem === item.name),
                    'text-gray-600': hovered
                      ? hovered !== item.name
                      : activeItem !== item.name,
                  })}
                >
                  {item.name}
                </span>
              </Link>
            ))}
          </nav>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          className="hover:bg-transparent md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          <Menu className="h-6 w-6" />
          <span className="sr-only">{mobileMenuOpen ? 'Close' : 'Menu'}</span>
        </Button>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <>
              {/* Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm md:hidden"
                onClick={() => setMobileMenuOpen(false)}
              />

              {/* Menu Panel */}
              <motion.div
                ref={mobileMenuRef}
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'tween', ease: 'easeInOut', duration: 0.3 }}
                className="fixed inset-y-0 right-0 z-50 w-full max-w-sm bg-white shadow-xl md:hidden"
              >
                <div className="flex h-full flex-col overflow-y-auto">
                  {/* Header */}
                  <div className="flex items-center justify-between border-b p-4">
                    <Link
                      href="/"
                      className="text-lg font-medium px-4 py-1 border border-black rounded-full"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Reverie
                    </Link>
                    <button
                      onClick={() => setMobileMenuOpen(false)}
                      className="rounded-md p-2 text-gray-500 hover:bg-gray-100"
                      aria-label="Close menu"
                    >
                      <X className="h-6 w-6" />
                    </button>
                  </div>

                  {/* Navigation */}
                  <nav className="flex-1 px-2 py-4 space-y-1">
                    {navItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = activeItem === item.name;

                      return (
                        <Link
                          key={item.name}
                          href={item.href}
                          className={cn(
                            'group flex items-center px-4 py-3 text-sm font-medium rounded-md',
                            isActive
                              ? 'bg-gray-700 text-white'
                              : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                          )}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <Icon
                            className={cn(
                              'mr-3 h-5 w-5 flex-shrink-0',
                              isActive
                                ? 'text-white'
                                : 'text-gray-400 group-hover:text-gray-500'
                            )}
                            aria-hidden="true"
                          />
                          {item.name}
                        </Link>
                      );
                    })}
                  </nav>

                  {/* Footer */}
                  <div className="border-t border-gray-200 p-4 text-xs text-muted-foreground flex items-center gap-2">
                    <Code2 />
                    Developed & managed by Synctom
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
