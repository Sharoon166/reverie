import Loading from '@/components/ui/loading';

export default function LoadingPage() {
  return <Loading />;
}
