// CRUD helpers (wrappers for Appwrite queries)
